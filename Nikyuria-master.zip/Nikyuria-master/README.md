The last cheat I ever created ( or well not really last, made one more after this but didn't finish tha one ).
Releasing it because it even I sold a copy because of it being leaked to Kittix, and Kittix claiming credit.
Since even a year after it's still happening, I decide that it's time to release it.

It has some "new" cheat features that the scene might appreciate ( aka will probably be c+pd into every generic cheat ), but since it's already happening with 1 cheat,
it doesn't really matter.

The cheat used to work for csgo, tf2, gmod, css and it probably would've worked for many others.

Use it for whatever you want, just make sure to credit me.

Creds to nano for helping me get into RE and some help like the FindString or CalcAbsAddress stuff. 

Creds to fami for the new menu sketchup, even though I was too lazy to actually ever implent it :v:

Creds to James & Sasha for moral support

Creds to Matt for killing my fishes with too much fodder

Creds to Nub for financial help


I don't think anybody else helped me with this.

Don't forget to change the hash.
