#pragma once

#include "namechanger.h"


m_NameChanger *NameChanger = NULL;

char letters[99] = { 'a', 'A', 'E', 'e', 'o', 'y', 'H', 'T', 'M', 'C', 'c', 'B', 'P', 'p', 'X', 'x', 'K' };
char *swapletters[99] = { "\xD0\xB0", "\xD0\x90", "\xD0\x95", "\xD0\xB5", "\xD0\xBE", "\xD1\x83", "\xD0\x9D", "\xD0\xA2", "\xD0\x9C", "\xD0\xA1", "\xD1\x81", "\xD0\x92", "\xD0\xA0", "\xD1\x80", "\xD0\xA5", "\xD1\x85", "\xD0\x9A" };

