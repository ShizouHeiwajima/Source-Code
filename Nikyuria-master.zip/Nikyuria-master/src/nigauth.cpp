#include "nigauth.h"

/*
-------------------------- -
904014425
-------------------------- -
a
-------------------------- -
OK
-------------------------- -
*/

const InstructionSet::InstructionSet_Internal InstructionSet::CPU_Rep;
nigauth auth;